<?
define('C_REST_CLIENT_ID','app.639304d14e2d26.07025814');//Application ID
define('C_REST_CLIENT_SECRET','VBMbwrbCzuVLwTyx1qoJ3GgsqyYznldZjwd31RwMTPUNLrhdRM');//Application key
// or
// define('C_REST_WEB_HOOK_URL','https://rest-course.bitrix24.ru/rest/1/j0nzq02mzvzmx9lx/');//url on creat Webhook

//define('C_REST_CURRENT_ENCODING','windows-1251');
//define('C_REST_IGNORE_SSL',true);//turn off validate ssl by curl
//define('C_REST_LOG_TYPE_DUMP',true); //logs save var_export for viewing convenience
//define('C_REST_BLOCK_LOG',true);//turn off default logs
//define('C_REST_LOGS_DIR', __DIR__ .'/logs/'); //directory path to save the log